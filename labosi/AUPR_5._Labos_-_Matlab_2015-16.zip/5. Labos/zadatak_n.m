Gp_s=tf([10],[0.25 1]);
Gr_s=tf([sqrt(41)/8],[1 0]);

Gp_z1=c2d(Gp_s,0.02,'zoh');
Gp_z2=c2d(Gp_s,0.05,'zoh');
Gp_z3=c2d(Gp_s,0.1,'zoh');
Gp_z4=c2d(Gp_s,0.5,'zoh');

Gr_z1=c2d(Gr_s,0.02,'tustin');
Gr_z2=c2d(Gr_s,0.05,'tustin');
Gr_z3=c2d(Gr_s,0.1,'tustin');
Gr_z4=c2d(Gr_s,0.5,'tustin');

Go_z1=Gp_z1*Gr_z1;
Go_z2=Gp_z2*Gr_z2;
Go_z3=Gp_z3*Gr_z3;
Go_z4=Gp_z4*Gr_z4;

G_z1=Go_z1/(1+Go_z1);
G_z2=Go_z2/(1+Go_z2);
G_z3=Go_z3/(1+Go_z3);
G_z4=Go_z4/(1+Go_z4);

G_z1=minreal(G_z1);
G_z2=minreal(G_z2);
G_z3=minreal(G_z3);
G_z4=minreal(G_z4);

pzmap(G_z1,G_z2,G_z3,G_z4);
legend('T = 20 ms','T = 50 ms','T = 100 ms','T = 500 ms')