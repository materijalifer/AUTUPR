Go_s=tf([5*sqrt(41)],[1 4 0]);

Go_omega=c2d(Go_s,0.05,'zoh');
Go_omega=0.7209997892*Go_omega;

bode(Go_s,'b--',Go_omega,'r');

legend('KONTINUIRANI','DISKRETNI TIb');