T = 0.05; % period uzorkovanja
Go_z = tf([(1-exp(-0.2))*sqrt(41)/32 (1-exp(-0.2))*sqrt(41)/32], [1 -1-exp(-0.2) exp(-0.2)], T); % diskretna prijenosna funkcija
Go_z_sym = tf2sym(Go_z); % prebacuje u simbolicki format
syms z om
Go_om_sym = subs(Go_z_sym, z, (1+om*T/2)/(1-om*T/2)); % supstitucija
Go_om = sym2tf(Go_om_sym); % natrag u control format
Go_om = minreal(Go_om) % kracenje eventualnih bliskih polova i nula
zpk(Go_om) % "s" ovdje treba interpretirati kao "Omega"