Gp_s=tf([10],[0.25 1]);

Gp_omega1=c2d(Gp_s,0.02,'zoh');
Gp_omega2=c2d(Gp_s,0.05,'zoh');
Gp_omega3=c2d(Gp_s,0.1,'zoh');
Gp_omega4=c2d(Gp_s,0.5,'zoh');

zgrid;
pzmap(Gp_omega1,Gp_omega2,Gp_omega3,Gp_omega4);
%grid on;

legend('T = 20 ms','T = 50 ms','T = 100 ms','T = 500 ms')