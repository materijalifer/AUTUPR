open zadatak2g_PI
sim('zadatak2g_PI',110);

figure;
subplot(4,1,1);
plot(tout,y);
grid;
xlabel('Vrijeme [s]');
ylabel('Amplituda');
title('Izlaz procesa, PI');

subplot(4,1,2);
plot(u,'r');
grid;
xlabel('Vrijeme [s]');
ylabel('Amplituda');
title('Upravlja�ka veli�ina, PI');


open zadatak2g_PID
sim('zadatak2g_PID',110);

subplot(4,1,3);
plot(tout,y);
grid;
xlabel('Vrijeme [s]');
ylabel('Amplituda');
title('Izlaz procesa, PID');

subplot(4,1,4);
plot(u,'r');
grid;
xlabel('Vrijeme [s]');
ylabel('Amplituda');
title('Upravlja�ka veli�ina, PID');
