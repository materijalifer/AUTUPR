open zadatak1b
sim('zadatak1b',110);

figure;
subplot(2,1,1);
plot(tout,y);
grid;
xlabel('Vrijeme [s]');
ylabel('Amplituda');
title('Izlaz procesa');

subplot(2,1,2);
plot(tout,u,'r');
grid;
xlabel('Vrijeme [s]');
ylabel('Amplituda');
title('Upravlja�ka veli�ina');