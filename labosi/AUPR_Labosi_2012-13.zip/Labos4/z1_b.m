clear;
clc;
s = tf('s');
G1 = 5*(s-1)/(2*s*(s-1)*(s+5));
G2 = 5*(s+2)/(0.5*s*(s-1)*(s+5));
G3 = 5*(s+2)/(1/3*s*(s-1)*(s+5));

subplot(3,1,1)
step(minreal(feedback(G1,1)));
grid;
xlabel('Vrijeme [t]');
ylabel('Amplituda');
title('T = 2, a = -1');

subplot(3,1,2)
step(minreal(feedback(G2,1)));
grid;
xlabel('Vrijeme [t]');
ylabel('Amplituda');
title('T = 0.5, a = 2');

subplot(3,1,3)
step(minreal(feedback(G3,1)));
grid;
xlabel('Vrijeme [t]');
ylabel('Amplituda');
title('T = 1/3, a = 2');
