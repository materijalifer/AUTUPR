clear;
clc;
s = tf('s');
%Prijenosna funkcija otvorenog kruga
Go = 85 * 400/(s*(s+5)*(s+80));

%Crtanje Bodeovog dijagrama sa ozna�enim amplitudnim i faznim osiguranjem
figure('name','Bodeov dijagram');
margin(minreal(Go));
grid;
title('Bodeov dijagram')

%Crtanje Nyquistovog dijagrama
figure('name','Nyquistov dijagram');
nyquist(Go);


%Crtanje prijelazne funkcije zatvorenog kruga

figure('name','Prijelazna funkcija zatvorenog kruga');
Gr = feedback(Go,1);
step(Gr);
grid;
title('Prijelazna funkcija');
