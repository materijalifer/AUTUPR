%Prelapanje preklopke i crtanje odziva i odstupanja
open shema.mdl
T = 0.5; %Postavi parametar T
a = 1;   %Postavi parametar a



set_param('shema/Manual Switch','sw','1') %Preklopka pu�ta step
sim('shema',20); %Pokretanje simulacije
%__________________________________________________________________
subplot(2,2,1);  %Crtanje odziva
plot(tout(:),y(:));
hold on;
grid;
xlabel('Vrijeme [s]');
ylabel('Amplituda');
title('Odziv sustava(step)');

subplot(2,2,3);  %Crtanje regulacijskog odstupanja
plot(tout(:),e(:));
hold on;
grid;
xlabel('Vrijeme [s]');
ylabel('Amplituda');
title('Regulacijsko odstupanje(step)');
%__________________________________________________________________
set_param('shema/Manual Switch','sw','0') %Preklopka pu�ta rampu
sim('shema',20); %Pokretanje simulacije
%__________________________________________________________________
subplot(2,2,2);  %Crtanje odziva
plot(tout(:),y(:),'r');
grid
xlabel('Vrijeme [s]');
ylabel('Amplituda');
title('Odziv sustava(rampa)');

subplot(2,2,4);  %Crtanje regulacijskog odstupanja
plot(tout(:),e(:),'r');
grid
xlabel('Vrijeme [s]');
ylabel('Amplituda');
title('Regulacijsko odstupanje(rampa)');