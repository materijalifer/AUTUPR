clear;
clc;
s = tf('s');
Go = 40.11867 * 400 /(s*(s+5)*(s+80));
Gr = feedback(Go,1);
step(Gr);
