open zdk
sim('zdk',3);
plot(tout,kont);
hold on;
grid;
plot(tout,disk,'r');
legend('Kontinuirani regulator','Diskretni regulator');
xlabel('Vrijeme [s]');
ylabel('Amplituda');

