open zdl
sim('zdl',2.5);

figure;
subplot(2,1,1);
grid;
hold on;
plot(tout,cont);
plot(tout,ms10,'r');
plot(tout,ms45,'g');
plot(tout,ms100,'y');

xlabel('Vrijeme [s]');
ylabel('Amplituda');
title('Prijelazne funkcije za razli�ite periode diskretizacije');
legend('Kontinuirani Regulator','Regulator T = 10ms','Regulator T = 45ms','Regulator T = 100ms');
subplot(2,1,2);
hold on;
plot(tout,cont);
plot(tout,ms450,'k');
grid;
xlabel('Vrijeme [s]');
ylabel('Amplituda');
legend('Kontinuirani Regulator','Regulator T = 450ms')