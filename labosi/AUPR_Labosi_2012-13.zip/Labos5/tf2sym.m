function Gsym = tf2sym(Gtf)
% Pretvara prijenosnu funkciju u simbolicki izraz sa simbolickom varijablom 's' ako je kont., odnosno 'z' ako je diskretni

% Misel Brezak, misel.brezak@fer.hr

[br,naz] = tfdata(Gtf);
if(isdt(Gtf))
	% Za diskretne sustave
	syms z;
	Gsym = poly2sym(cell2mat(br),z)/poly2sym(cell2mat(naz),z);
else
	syms s;
	Gsym = poly2sym(cell2mat(br),s)/poly2sym(cell2mat(naz),s);
end
