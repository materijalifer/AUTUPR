s = tf('s');
Gp = 25/(1+0.15*s);

Gpd1 = c2d(Gp,0.01,'zoh');
Gpd2 = c2d(Gp,0.045,'zoh');
Gpd3 = c2d(Gp,0.1,'zoh');
Gpd4 = c2d(Gp,0.45,'zoh');
pzmap(Gpd1)
hold on;
pzmap(Gpd2)
pzmap(Gpd3)
pzmap(Gpd4)
legend('T=10ms','T=45ms','T=100ms','T=450ms');