s = tf('s');
GR = 1/(4*s);
GRd1 = c2d(GR,0.01,'tustin');
GRd2 = c2d(GR,0.045,'tustin');
GRd3 = c2d(GR,0.1,'tustin');
GRd4 = c2d(GR,0.45,'tustin');

Gp = 25/(1+0.15*s);
Gpd1 = c2d(Gp,0.01,'zoh');
Gpd2 = c2d(Gp,0.045,'zoh');
Gpd3 = c2d(Gp,0.1,'zoh');
Gpd4 = c2d(Gp,0.45,'zoh');

Go1 = GRd1*Gpd1;
Go2 = GRd2*Gpd2;
Go3 = GRd3*Gpd3;
Go4 = GRd4*Gpd4;

Gz1 = Go1/(1+Go1);
Gz2 = Go2/(1+Go2);
Gz3 = Go3/(1+Go3);
Gz4 = Go4/(1+Go4);

pzmap(Gz1);
hold on;
pzmap(Gz2);
pzmap(Gz3);
pzmap(Gz4);

legend('T=10 ms','T=45 ms','T=100 ms','T=450 ms');
