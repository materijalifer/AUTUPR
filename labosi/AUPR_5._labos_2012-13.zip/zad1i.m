% Prijenosna funkcija s kontinuiranim regulatorom
B=[6.25]
N=[0.15 1 0]
bode(B,N)
grid on
hold on

% Prijenosna funkcija s diskretnim regulatorom
B=[-0.0225 1]
N=[0.617*0.03915 0.617*0.26 0]
bode(B,N)
