function [G_tf] = sym2tf(G_sym)
% Pretvara simbolicku prijenosnu funkciju u control format

% Mi�el Brezak, misel.brezak@fer.hr

[br_sym, naz_sym] = numden (G_sym);

br_tf = sym2poly (br_sym);
naz_tf = sym2poly (naz_sym);

% Normalizacija koeficijenata tako da koeficijent uz najvecu potenciju nazivnika bude 1
br_tf = br_tf / naz_tf(1); 
naz_tf = naz_tf / naz_tf(1); 

G_tf = tf (br_tf, naz_tf);
