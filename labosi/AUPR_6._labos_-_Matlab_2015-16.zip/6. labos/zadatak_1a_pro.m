Gp1_s=tf([2.25],[2 1 1]);
Gp2_s=tf([1],[6 1]);
Gp_s=Gp1_s*Gp2_s;
Gr_s=optimPID(Gp_s,2,1);