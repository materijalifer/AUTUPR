syms s

Gp1_s=tf([2.25],[2 1 1]);
Gp2_s=tf([1],[6 1]);
Gp_s=Gp1_s*Gp2_s;

[k,ku,pu]=znpidtuning(Gp_s,2);
GrPI_s=tf([k.kc k.kc/k.ti],[1 0]);

[k,ku,pu]=znpidtuning(Gp_s,3);
Tni=0.2*k.td;
GrPIDreal_s=k.kc*(1+1/(k.ti*s)+k.td*s/(1+Tni*s));
GrPIDreal_s=sym2tf(GrPIDreal_s);
GrPIDreal_s=minreal(GrPIDreal_s);