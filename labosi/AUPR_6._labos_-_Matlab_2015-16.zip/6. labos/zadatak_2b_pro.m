syms s

Gp1_s=tf([2.25],[2 1 1]);
Gp2_s=tf([1],[6 1]);
Gp_s=Gp1_s*Gp2_s;

[k,ku,pu]=znpidtuning(Gp_s,3);
Gr_s=tf([k.kc*k.td k.kc k.kc/k.ti],[1 0]);

Go_s=Gr_s*Gp_s;
Go_s=minreal(Go_s);
wc=getGainCrossover(Go_s,1)
T=(0.17+0.34)/(2*wc);

Gr_z=c2d(Gr_s,T,'tustin');