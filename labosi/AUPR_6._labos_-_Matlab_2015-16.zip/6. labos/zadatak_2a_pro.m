Gp1_s=tf([2.25],[2 1 1]);
Gp2_s=tf([1],[6 1]);
Gp_s=Gp1_s*Gp2_s;

[k,ku,pu]=znpidtuning(Gp_s,2);
GrPI_s=tf([k.kc k.kc/k.ti],[1 0]);

[k,ku,pu]=znpidtuning(Gp_s,3);
GrPID_s=tf([k.kc*k.td k.kc k.kc/k.ti],[1 0]);