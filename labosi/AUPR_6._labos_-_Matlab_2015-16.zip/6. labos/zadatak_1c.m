syms s Kr Ti real;

c0=Ti;
c1=Ti;
c2=2*Ti;
c3=0;

d0=2.25*Kr;
d1=(1+2.25*Kr)*Ti;
d2=7*Ti;
d3=8*Ti;
d4=12*Ti;

Ibr=(c3^2*(-d0^2*d3+d0*d1*d2)+(c2^2-2*c1*c3)*d0*d1*d4+(c1^2-2*c0*c2)*d0*d3*d4+c0^2*(-d1*d4^2+d2*d3*d4));
Inaz=2*d0*d4*(-d0*d3^2-d1^2*d4+d1*d2*d3);
I=simplify(Ibr/Inaz);
[Kr Ti]=solve(diff(I,Ti),diff(I,Kr),Kr,Ti);
Kr=double(Kr);
Ti=double(Ti);
%Kr=real(Kr(2,1));
%Ti=real(Ti(4,1));

%Gr_s=Kr*(1+1/(Ti*s));
%[n d]=numden(Gr_s);
%n=sym2poly(n);
%d=sym2poly(d);
%Gr_s=tf(n,d);
%Gr_s=minreal(Gr_s);