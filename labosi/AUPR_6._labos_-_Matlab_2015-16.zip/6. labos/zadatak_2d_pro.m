syms s

Gp1_s=tf([2.25],[2 1 1]);
Gp2_s=tf([1],[6 1]);
Gp_s=Gp1_s*Gp2_s;

[k,ku,pu]=znpidtuning(Gp_s,3);
Tni=0.2*k.td;
Gr_s=k.kc*(1+1/(k.ti*s)+k.td*s/(1+Tni*s));
Gr_s=sym2tf(Gr_s);

Go_s=Gr_s*Gp_s;
Go_s=minreal(Go_s);
wc=getGainCrossover(Go_s,1)
T=(0.17+0.34)/(2*wc);

Gr_z=c2d(Gr_s,T,'tustin');