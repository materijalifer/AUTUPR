% Prikazuje Bodeove i Nyqistove dijagrame te prijelazne funkcije.
disp('Stabilnost sustava o parametrima K i a')
%Unos parametara za brojnik prijenosne funkcije otvorenog kruga.
K1 = input('Unesite vrijednost parametra K1;  K1=');
a1 = input('Unesite vrijednost parametra a1;  a1=');
B1 = [5*K1 5*K1*a1];
K2 = input('Unesite vrijednost parametra K2;  K2=');
a2 = input('Unesite vrijednost parametra a2;  a2=');
B2 = [5*K2 5*K2*a2];
K3 = input('Unesite vrijednost parametra K3;  K3=');
a3 = input('Unesite vrijednost parametra a3;  a3=');
B3 = [5*K3 5*K3*a3];
%Nazivnik prijenosne funkcije otvorenog kruga.
N = [1 4 -5 0];
%Prijenosne funkcije otvorenog kruga.
G_1o = tf(B1,N);
G_2o = tf(B2,N);
G_3o = tf(B3,N);
%Bodeovi dijagrami.
figure; margin(G_1o); grid on;
figure; margin(G_2o); grid on;
figure; margin(G_3o); grid on;
%Nyquistovi dijagrami.
figure;
nyquist(G_1o); hold on;
nyquist(G_2o); hold on;
nyquist(G_3o); hold on;
xlim([-8 9]); ylim([-50 50]);
%Nyquistovi dijagrami za bolji prikaz to�ke Re = -1, Im = 0.
figure;
nyquist(G_1o); hold on;
nyquist(G_2o); hold on;
nyquist(G_3o); hold on;
xlim([-2 2]); ylim([-2 2]);
Cloop_1 = feedback(G_1o,1);
Cloop_2 = feedback(G_2o,1);
Cloop_3 = feedback(G_3o,1);
%Prijelazne funkcije. Ako su parametri K1, K2 i K3 te a1, a2 i a3
%druga�iji, kod naredbe title potrebno je promijeniti te iznose.
figure;
subplot(3,1,1);
step(minreal(Cloop_1));
title('$$K = -1$$, $$a = 9$$','Interpreter','latex','FontSize',12);
xlabel('$$t$$','Interpreter','latex','FontSize',12);
ylabel('$$h_{1} \left ( t \right )$$','Interpreter','latex','FontSize',12);
grid on; %Opcionalno. Mo�e se maknuti ukoliko ne �elite grid.
hold on;
subplot(3,1,2);
step(minreal(Cloop_2));
title('$$K = 2$$, $$a = 2$$','Interpreter','latex','FontSize',12);
xlabel('$$t$$','Interpreter','latex','FontSize',12);
ylabel('$$h_{2} \left ( t \right )$$','Interpreter','latex','FontSize',12);
grid on; %Opcionalno. Mo�e se maknuti ukoliko ne �elite grid.
hold on;
subplot(3,1,3);
step(minreal(Cloop_3));
title('$$K = 3$$, $$a = 2$$','Interpreter','latex','FontSize',12);
xlabel('$$t$$','Interpreter','latex','FontSize',12);
ylabel('$$h_{3} \left ( t \right )$$','Interpreter','latex','FontSize',12);
grid on; %Opcionalno. Mo�e se maknuti ukoliko ne �elite grid.
hold on;