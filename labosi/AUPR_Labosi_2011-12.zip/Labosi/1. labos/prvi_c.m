sym krug_izlaz
krug_izlaz=dsolve('5+2.5*heaviside(t-0.001)=u2*(1+100/400)+Du2*(2*10^-6*100+0.05/400)+D2u2*(100*0.05*2*10^-6/400)','u2(0)=0,Du2(0)=4');
ezplot(krug_izlaz,[0 0.01]);
hold on

simplot(prvi_d);
axis([0 0.01 4 6.5])

