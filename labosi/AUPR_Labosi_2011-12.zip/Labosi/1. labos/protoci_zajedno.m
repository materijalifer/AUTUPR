simplot(manji_otvor_qi,'r');
hold on

simplot(veci_otvor_qi);
axis([0 10000 -1 6.5])