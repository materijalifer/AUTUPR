



G = tf([2 2],[1/14 9/14 1])
figure(1)
bodeplot(G)

figure(2)
nyquist(G)
