G1brojnik=2;
G2brojnik=4;
G1nazivnik=[2 2 1];
G2nazivnik=[1 2 2];
G1 = tf(G1brojnik,G1nazivnik,'r');
G2 = tf(G2brojnik,G2nazivnik,'g');
figure(5)
pzmap(G1,G2)
grid on 
figure(6)
step(G1brojnik,G1nazivnik,'b')
hold on
step(G2brojnik,G2nazivnik,'g')


