H1brojnik=[-7 28];
H2brojnik=[14 28];
H3brojnik=[28 28];
Hnazivnik=[1 9 14];
H1 = tf(H1brojnik,Hnazivnik,'b-');
H2 = tf(H2brojnik,Hnazivnik,'g-');
H3 = tf(H3brojnik,Hnazivnik,'r-');

figure(3)
pzmap(H1,H2,H3)
grid on
figure(4)
step(H1brojnik,Hnazivnik,'b')
grid on
hold on
step(H2brojnik,Hnazivnik,'g')
grid on
hold on
step(H3brojnik,Hnazivnik,'r')
grid on
hold on
 
