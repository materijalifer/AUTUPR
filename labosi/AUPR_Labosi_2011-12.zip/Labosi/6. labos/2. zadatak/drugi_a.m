Hbrojnik=[3.41712 3.36 0.7932];
Hnazivnik=[20 12 11 1 0];
H = tf(Hbrojnik,Hnazivnik);





figure(2)


margin(H)












 
