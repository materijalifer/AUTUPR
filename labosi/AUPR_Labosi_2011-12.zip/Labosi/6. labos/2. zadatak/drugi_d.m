Hbrojnik=[1.37847 3.521 0.7932];
Hnazivnik=[4.068 22.4408 14.2374 11.2034 1 0];
H = tf(Hbrojnik,Hnazivnik);





figure(2)


margin(H)












 
