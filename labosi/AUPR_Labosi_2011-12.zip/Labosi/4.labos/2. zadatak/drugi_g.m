H4brojnik=[16047.5006];
H4nazivnik=[1 85 400 16047.5006];
H4 = tf(H4brojnik,H4nazivnik);





figure(4)
 
step(H4brojnik,H4nazivnik,'g')
title('prijelazna fja fazno osiguranje=15 stupnjeva')










 
