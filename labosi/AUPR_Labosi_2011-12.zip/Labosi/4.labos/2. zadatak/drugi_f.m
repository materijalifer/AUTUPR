Hbrojnik=[34000];
Hnazivnik=[1 85 400 34000];
H = tf(Hbrojnik,Hnazivnik);

G = tf([34000],[1 85 400 0]);



figure(3)

subplot(3,1,1);
margin(G)


subplot(3,1,2);
nyquist(G)
title('nyquist ')

subplot(3,1,3); 
step(Hbrojnik,Hnazivnik,'g')
title('prijelazna fja zatvorenog kruga')










 
