H1brojnik=[-5 -45];
H1nazivnik=[1 4 -10 -45];

H2brojnik=[10 20];
H2nazivnik=[1 4 5 20];

H3brojnik=[15 30];
H3nazivnik=[1 4 10 30];

H1 = tf(H1brojnik,H1nazivnik,'b-');
H2 = tf(H2brojnik,H2nazivnik,'g-');
H3 = tf(H3brojnik,H3nazivnik,'r-');

figure(1)

subplot(3,1,1); 
step(H1brojnik,H1nazivnik,'b')
title('K=-1 a=9')


subplot(3,1,2); 
step(H2brojnik,H2nazivnik,'g')
title('K=2 a=2')



subplot(3,1,3); 
step(H3brojnik,H3nazivnik,'r')
title('K=3 a=2')




 
